#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

struct Course {
	string courseNumber;
	string name;
	vector<string>prerequisites;
};

int main()
{
	cout << "Welcome to the course Planner\n";
	while (true)
	{
		int flag;
		string flag2;
		flag = 0;
		cout << "\t 1.Load Data Structure.\n";
		cout << "\t 2.Print Course List.\n";
		cout << "\t 3.Print Course.\n";
		cout << "\t 9.Exit.\n";
		cout << "What would you like to do ?";
		cin >> flag;
		cout << "\n";
		if (flag == 9)
		{
			break;
		}
		else if (flag == 1)
		{
			//define your load data strucure
		}
		else if (flag == 2)
		{
			cout << "Here is sample schedule:\n\n";
			cout << "CSCI100, Introduction to Computer Science\n";
			cout << "CSCI101, Introduction to Programming in C++\n";
			cout << "CSCI200, Data Structures\n";
			cout << "CSCI301, Advance Programming in C++\n";
			cout << "CSCI300, Introduction to Algorithms\n";
			cout << "CSCI350, Operating Systems\n";
			cout << "CSCI400, Large Software Development\n";
			cout << "MATH201, Discrete Mathematics\n\n";
		}
		else if (flag == 3)
		{
			cout << "What course do you want to know about?";
			cin >> flag2;
			cout << "\n";
			transform(flag2.begin(), flag2.end(), flag2.begin(), ::tolower);
			if (flag2 == "csci400")
			{
				cout << "CSCI400,Large Software Development\nPrerequisites:CSCI301, CSCI350\n\n";
			}
			//Write for other Courses using Else If statement
		}
		else
		{
			cout < cout << " is not a valid option\n";
		}
	}

	return 0;
}
		// Function to print course information
	void printCourseInfo(vector<Course> courses, string courseNumber) {
		Course* course = nullptr;
		for	(Course& c : courses) {
			if (c.number == courseNumber) {
				course = &c;
			break;
		}
	}

	if (course != nullptr) {
		cout << "Course Title: " << course->title << endl;
		if (!course->prerequisites.empty()) {
			cout << "Prerequisites: ";
			for (string prereq :

		// Function to print a list of courses
	void printCourseList(vector<Course> courses) {
		sort(courses.begin(), courses.end(), [](Course a, Course b) {
			return a.number < b.number;
		});

	cout << "Course List:" << endl;
	for (Course course : courses) {
		cout << course.number << " " << course.title << endl;
	}
}
